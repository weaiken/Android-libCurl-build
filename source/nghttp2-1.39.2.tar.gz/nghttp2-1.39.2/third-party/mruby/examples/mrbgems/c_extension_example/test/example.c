#include <mruby.h>

void
mrb_c_extension_example_gem_test(mrb_state *mrb)
{
  /* test initializer in C */
}

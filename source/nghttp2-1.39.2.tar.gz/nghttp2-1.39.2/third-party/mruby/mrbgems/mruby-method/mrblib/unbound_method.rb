class UnboundMethod
  def owner
    @owner
  end

  def name
    @name
  end
end

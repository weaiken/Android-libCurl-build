sleep(10)
usleep(10000)

